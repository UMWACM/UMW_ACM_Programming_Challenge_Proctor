public class Easy {
    public static void main(String args[]) {
        try {
            new Easy().doIt();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void doIt() throws Exception {
        java.util.Scanner input = new java.util.Scanner(System.in);
        int numNums = input.nextInt();
        long total = 0;
        for (int i=0; i<numNums; i++) {
            long num = input.nextLong();
            total += num;
        }
        System.out.println(total);
    }
}
