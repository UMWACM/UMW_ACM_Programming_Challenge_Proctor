/**
 * A probabalistic test for equivelance of two algebraic equations
 * using a random variable replacement and Javascript evaluation.
 * Author: Jeffrey McAteer
 */
import java.util.Scanner;
import java.util.Random;
import java.util.HashMap;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
public class JeffDifficult {
  
  public static Scanner in = new Scanner(System.in);
  public static ScriptEngineManager script_man = new ScriptEngineManager();
  public static ScriptEngine javascript = script_man.getEngineByName("JavaScript");
  public static Random rand = new Random();
  
  public static void main(String... args) throws Exception {
    int vars = Integer.parseInt(in.nextLine());
    String[] eq1 = in.nextLine().toLowerCase().split("=");
    assert eq1.length == 2;
    String[] eq2 = in.nextLine().toLowerCase().split("=");
    assert eq2.length == 2;
    int tests = 10000;
    while ( tests-->0 ) {
      boolean this_test_works = false;
      try {
        this_test_works = eval(vars, eq1[0], eq1[1], eq2[0], eq2[1]);
      } catch (Exception e) {
        // e.printStackTrace();
        // Ignored
      }
      if (this_test_works) {
        System.out.println("equivalent");
        return;
      }
    }
    System.out.println("not equivalent");
  }
  
  public static boolean eval(int num_vars, String left_eq1, String right_eq1, String left_eq2, String right_eq2) throws Exception {
    int left_eq1_offset = 0, right_eq1_offset = 0, left_eq2_offset = 0, right_eq2_offset = 0;
    int max_rand = 50;
    HashMap<Character, Integer> var_map = new HashMap<Character, Integer>();
    for (int i=0; i<num_vars; i++) {
      char left_eq1_var = get_var(left_eq1_offset, left_eq1);
      if (left_eq1_var != '\0' && !var_map.containsKey(left_eq1_var)) {
        left_eq1_offset = left_eq1.indexOf(left_eq1_var, left_eq1_offset);
        var_map.put(left_eq1_var, Math.abs(rand.nextInt()) % max_rand);
      }
      char right_eq1_var = get_var(right_eq1_offset, right_eq1);
      if (right_eq1_var != '\0' && !var_map.containsKey(right_eq1_var)) {
        right_eq1_offset = right_eq1.indexOf(right_eq1_var, right_eq1_offset);
        var_map.put(right_eq1_var, Math.abs(rand.nextInt()) % max_rand);
      }
      char left_eq2_var = get_var(left_eq2_offset, left_eq2);
      if (left_eq2_var != '\0' && !var_map.containsKey(left_eq2_var)) {
        left_eq2_offset = left_eq2.indexOf(left_eq2_var, left_eq2_offset);
        var_map.put(left_eq2_var, Math.abs(rand.nextInt()) % max_rand);
      }
      char right_eq2_var = get_var(right_eq2_offset, right_eq2);
      if (right_eq2_var != '\0' && !var_map.containsKey(right_eq2_var)) {
        right_eq2_offset = right_eq2.indexOf(right_eq2_var, right_eq2_offset);
        var_map.put(right_eq2_var, Math.abs(rand.nextInt()) % max_rand);
      }
    }
    for (Character var : var_map.keySet()) {
      int num = var_map.get(var);
      left_eq1 = replace_var(var, num, left_eq1);
      right_eq1 = replace_var(var, num, right_eq1);
      left_eq2 = replace_var(var, num, left_eq2);
      right_eq2 = replace_var(var, num, right_eq2);
    }
    //System.err.println("Evaluating left_eq1 = "+left_eq1);
    //System.err.println("Evaluating right_eq1 = "+right_eq1);
    //System.err.println("Evaluating left_eq2 = "+left_eq2);
    //System.err.println("Evaluating right_eq2 = "+right_eq2);
    
    Double left_eq1_eval = Double.parseDouble(""+javascript.eval(left_eq1));
    Double right_eq1_eval = Double.parseDouble(""+javascript.eval(right_eq1));
    Double left_eq2_eval = Double.parseDouble(""+javascript.eval(left_eq2));
    Double right_eq2_eval = Double.parseDouble(""+javascript.eval(right_eq2));
    
    //System.err.println("left_eq1_eval = "+ left_eq1_eval);
    //System.err.println("right_eq1_eval = "+ right_eq1_eval);
    //System.err.println("left_eq2_eval = "+ left_eq2_eval);
    //System.err.println("right_eq2_eval = "+ right_eq2_eval);
    return Math.round(left_eq1_eval) == Math.round(right_eq1_eval) &&
           Math.round(left_eq2_eval) == Math.round(right_eq2_eval);
  }
  
  public static char get_var(int beginning, String expr) {
    for (int i=beginning; i<expr.length(); i++) {
      if (Character.isLetter(expr.charAt(i))) {
        return expr.charAt(i);
      }
    }
    return '\0';
  }
  
  public static String replace_var(char var, int num, String expression) {
    return expression.replaceAll(""+var, ""+num);
  }
}
