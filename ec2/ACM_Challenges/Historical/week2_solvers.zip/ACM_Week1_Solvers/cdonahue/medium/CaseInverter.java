import java.util.Scanner;

public class CaseInverter {

	public static void main(String args[]) {

		Scanner input = new java.util.Scanner(System.in);
		String normal = input.nextLine();
		String inverted = "";
		for (int i = 0; i < normal.length(); i++) {

			if (Character.isLowerCase(normal.charAt(i))) {

				inverted = inverted + Character.toUpperCase(normal.charAt(i));

			}

			else if (Character.isUpperCase(normal.charAt(i))) {

				inverted = inverted + Character.toLowerCase(normal.charAt(i));

			}

			else {

				inverted = inverted + normal.charAt(i);

			}

		}

		System.out.println(inverted);

	}

}
