import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Joshua Wright
 */
public class Solution1 {
    String name;
    private ArrayList<String> friendAL;
    int rosters;
    
    /**
     * @param friends input string of friends separated by commas
     * saves data in variable friendAL
     */
    public void setFriends(String friends) {
        friendAL = new ArrayList<>(Arrays.asList(friends.split("\\s*,\\s*")));
    }
    
    public ArrayList getFriends() {
        return friendAL;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
    public void setRosters(int rosters) {
        this.rosters = rosters;
    }
    
    public int getRosters() {
        return rosters;
    }
    
    public int friendsInClass(ArrayList friends, ArrayList students) {
        students.retainAll(friends);
        return students.size();
    }
    
    
    public static void main(String[] args) {
        Solution1 mySolution = new Solution1();
        Scanner in = new Scanner(System.in);
        
        mySolution.setName(in.nextLine());
        mySolution.setFriends(in.nextLine());
        mySolution.setRosters(Integer.parseInt(in.nextLine()));
        
        String[] courseNames = new String[mySolution.getRosters()];
        
        HashMap<String, Integer> hashtable = new HashMap<>();
        
        for (int i = 0; i < mySolution.getRosters(); i++ ) {
            String className = in.nextLine();
            String classRoster = in.nextLine();
            courseNames[i] = className;
            
            ArrayList<String> classRosterAL = new ArrayList<>(Arrays.asList(classRoster.split("\\s*,\\s*")));
            
            if (classRosterAL.contains(mySolution.getName())) {
                hashtable.put(className, mySolution.friendsInClass(mySolution.getFriends(), classRosterAL));
            } else {
                hashtable.put(className, 0);
            } 
            
        }
        
        for(String key: courseNames){
            System.out.println(key+": "+hashtable.get(key));
        }
        
    }   
    
}
