import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

import static java.lang.System.out;

public class HiThere {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        String name = in.nextLine();
        HashSet<String> friends = new HashSet<>(Arrays.asList(in.nextLine().split(", ")));
        long rosterNum = in.nextLong();
        in.nextLine();
        LinkedHashMap<String, HashSet<String>> rosters = new LinkedHashMap<>();
        for (long i = 0; i < rosterNum; ++i) {
            rosters.put(in.nextLine(), new HashSet<>(Arrays.asList(in.nextLine().split(", "))));
        }

        for (Map.Entry<String, HashSet<String>> entry : rosters.entrySet()) {
            if (entry.getValue().contains(name)) {
                entry.getValue().retainAll(friends);
                out.println(entry.getKey() + ": " + entry.getValue().size());
            }
            else {
                out.println(entry.getKey() + ": 0");
            }
        }
    }
}
