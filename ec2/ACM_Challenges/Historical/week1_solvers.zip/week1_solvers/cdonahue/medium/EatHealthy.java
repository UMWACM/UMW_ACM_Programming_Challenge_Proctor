public class EatHealthy {
	public static void main(String args[]) {
		java.util.Scanner input = new java.util.Scanner(System.in);
		int dayCals = Integer.parseInt(input.nextLine());
		String foodCal = input.nextLine();
		String food = foodCal.split(": ")[0];
		int cals = Integer.parseInt(foodCal.split(": ")[1]);
		double servings = ((double)dayCals)/((double)cals);
		if (servings == 1) {
			System.out.println("I can eat 1 serving of " + food + " today!");
		}
		else if (servings % 1 == 0) {
			System.out.printf("I can eat %.0f servings of " + food + " today!\n", servings);
		}
		else {
			System.out.printf("I can eat %.2f servings of " + food + " today!\n", servings);
		}
	}
}
